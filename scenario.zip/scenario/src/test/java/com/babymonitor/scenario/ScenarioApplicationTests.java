package com.babymonitor.scenario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScenarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
